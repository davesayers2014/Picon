#!/bin/sh
#
echo Updating Package sources
eval opkg update

echo Updating wget component...
eval opkg install wget

echo Updating BASH shell...
eval opkg install bash

exit 0










